﻿
using System.Collections;
using System.Collections.Generic;

public class ScroggleTile : MonoBehaviour
{

    private string dataName;
    private string letter;
    private int gridLocationCol;
    private int gridLocationRow;
    private bool usedForWord;
    private int letterMultiplier = 1;
    private int tileMultiplier = 1;
    private int maxLocationCol;
    private int maxLocationRow;

    /// <summary>
    /// Sets the name of the tile. Represents its location.
    /// </summary>
    /// <param name="s">S.</param>
    public void SetName(string s)
    {
        dataName = s;
    }

    /// <summary>
    /// Sets the column location of this tile
    /// </summary>
    /// <param name="i">The index.</param>
    public void SetGridLocationCol(int i)
    {
        gridLocationCol = i;
    }

    /// <summary>
    /// Sets the grid location row.
    /// </summary>
    /// <param name="i">The index.</param>
    public void SetGridLocationRow(int i)
    {
        gridLocationRow = i;
    }

    /// <summary>
    /// Sets the tile multiplier.
    /// </summary>
    /// <param name="i">The index.</param>
    public void SetTileMultiplier(int i)
    {
        tileMultiplier = i;
    }

    //combined setting collumns and rows because lazy. and only ever used together.
    public void SetMaxLocationColRow(int c, int r)
    {
        maxLocationCol = c;
        maxLocationRow = r;
    }

    public void SetLetter(string l)
    {
        letter = l;
        CustomDebug.instance.DBPrint("checking for multipliers");
        letterMultiplier = ScroggleRuleset.instance.CheckForMultiplier(letter);
    }

    public void printAllValues()
    {
        string s = (dataName + ", " + letter + ", " + gridLocationCol + ", " + gridLocationRow + ", " + letterMultiplier + ", " + tileMultiplier);
        CustomDebug.instance.DBPrint(s);
    }

    public int GetGridLocationCol()
    {
        return gridLocationCol;
    }

    public int GetGridLocationRow()
    {
        return gridLocationRow;
    }

    /// <summary>
    /// A recursive method that calls tiles to solve the puzzle.
    /// </summary>
    /// <param name="sol">Sol.</param>
    /// <param name="wordList">Word list.</param>
    /// <param name="boardList">Board list.</param>
    /// <param name="blackList">Black list.</param>
    /// <param name="currentWordMultiplier">Current word multiplier.</param>
    /// <param name="currentWord">Current word.</param>
    public void RSolve(ScroggleSolver sol, List<string> wordList, List<ScroggleTile> boardList, List<ScroggleTile> blackList, int currentWordMultiplier, string currentWord)
    {
        //im sure unit testing would come VERY in handy for this method! >.<

        //create some temporary variables. these will be passed tot he next level of recursion or dropped entirely.
        string newWord = currentWord + letter;
        string ts; //temporary string.
        int mult = currentWordMultiplier * letterMultiplier * tileMultiplier;
        List<string> wordsToRemove = new List<string>();
        List<ScroggleTile> tempNeibours = new List<ScroggleTile>();
        List<ScroggleTile> alertList = new List<ScroggleTile>();//list of tiles to alert or query.

        //first check for any perfect matches. these will get reported to the solver.
        if (wordList.Contains(newWord))
        {
            //report the word to the solver.
            sol.receiveWordAndScore(newWord, mult);
            //remove this word fromm the list so it cant be counted more than once.
            wordList.Remove(newWord);
        }

        //then any partial matches. so we can pass these values to the next round.
        foreach (string s in wordList)
        {
            //break it down into a substring the same size as the string we need to compare it to.
            ts = s.Substring(0, newWord.Length);
            if (!ts.Equals(newWord))
            {
                //if the word does not match the string we are making then que it to be removed
                wordsToRemove.Add(s);
            }
        }

        //next we need to remove any words from the wordlist that no longer match up to the word we have.
        foreach (string s in wordsToRemove)
        {
            wordList.Remove(s);
        }

        //add this tile to the future tile blacklist so it cant get reused.
        blackList.Add(this);


        //now if the remaining word list has even a single value in it we need to check out neibours
        if (wordList.Count > 0)
        {
            //check the list of neibours for blacklisted enteries, if so remove them from the list.
            foreach (ScroggleTile st in boardList)
            {
                tempNeibours.Add(st);
            }

            foreach (ScroggleTile st in blackList)
            {
                tempNeibours.Remove(st);
            }

            //so use arithmetic to navigate the graph and grab a list of all applicable neibours.

            foreach (ScroggleTile st in tempNeibours)
            {
                //this may be a tough one here.
                //iterate through all of the neibours that arnt blacklisted. 
                //compare their location (colums and rows)to yours. if they are within one unit (+1/-1) then place them in the neibours list. 
                //print (st.printAllValues());
                if ((st.GetGridLocationCol() > gridLocationCol - 1 && st.GetGridLocationCol() < gridLocationCol + 1) || (st.GetGridLocationRow() > gridLocationRow - 1 && st.GetGridLocationRow() < gridLocationRow + 1))
                {
                    alertList.Add(st);
                }
            }

            //call this function on every member of the list neibour list.
            foreach (ScroggleTile st in alertList)
            {
                st.RSolve(sol, wordList, boardList, blackList, mult, newWord);
            }
        }


        //if our word list has nothing in it then we have tried every possible answer. return to sender!
        return;



    }



}
