﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Scroggle
{
    public class ScroggleSolver
    {

        //Begin by collecting all needed data from user.
        //create some variables to store our data.
        int boardHeight = 0;
        int boardWidth = 0;
        string lettersInOrder = null;
        string[] seperators = new string[] { "," };
        string[] lettersInOrderArray;
        string doubleValCoordinates = null;
        string[] doubleValCoordArray;
        string tripleValCoordinates = null;
        string[] tripleValCoordArray;
        string doubleValLetters = null;
        string[] doubleValLetArray;
        string tripleValLetters = null;
        string[] tripleValLetArray;
        string wordString = null;
        string[] wordArray;
        List<string> wordList = new List<string>();

        List<ScroggleTile> allTiles = new List<ScroggleTile>();

        List<ScroggleTile> blackList = new List<ScroggleTile>();

        int score;
        List<int> wordScore = new List<int>();
        List<string> foundWords = new List<string>();

        int oneToThreeLetterBaseScore = 0;
        int fourLetterWordBaseScore = 1;
        int fiveLetterWordBaseScore = 2;
        int sixLetterWordBaseScore = 3;
        int sevenLetterWordBaseScore = 5;
        int eightLetterWordBaseScore = 11;


        static void Main(string[] args)
        {
            ScroggleSolver s = new ScroggleSolver();
            s.GatherData();
            s.SolveScroggle(s);
            s.PrintFinalVals();
            Console.WriteLine("OperationCompleted Successfully.");
            Console.ReadLine();
            Console.WriteLine("Press ENTER to close.");
            Console.Read();
        }

        private void GatherData()
        {


            //pretty straight foward here. request information from user. parse information into useable form. repeat.
            Console.WriteLine("Whats is the boards height? (In an Integer Tiles)");
            boardHeight = Int32.Parse(Console.ReadLine());


            Console.WriteLine("Whats is the boards width? (In an Integer Tiles)");
            boardWidth = Int32.Parse(Console.ReadLine());


            Console.WriteLine("Please supply a comma-delimited list of letters that represent \nwhat the board looks like from top left to bottom right.");
            lettersInOrder = Console.ReadLine();
            lettersInOrderArray = lettersInOrder.Split(seperators, StringSplitOptions.None);


            Console.WriteLine("Please supply a comma-delimited list of \nboard coordinates for any double value tile. (top left is 0.0)");
            doubleValCoordinates = Console.ReadLine();
            doubleValCoordArray = doubleValCoordinates.Split(seperators, StringSplitOptions.None);


            Console.WriteLine("Please supply a comma-delimited list of \nboard coordinates for any triple value tile. (top left is 0.0)");
            tripleValCoordinates = Console.ReadLine();
            tripleValCoordArray = tripleValCoordinates.Split(seperators, StringSplitOptions.None);


            Console.WriteLine("please supply a comma-delimited list of \nletters that are granted a 2x bonus value");
            doubleValLetters = Console.ReadLine();
            doubleValLetArray = doubleValLetters.Split(seperators, StringSplitOptions.None);


            Console.WriteLine("please supply a comma-delimited list of \nletters that are granted a 3x bonus value");
            tripleValLetters = Console.ReadLine();
            tripleValLetArray = tripleValLetters.Split(seperators, StringSplitOptions.None);


            Console.WriteLine("please supply a comma-delimited list of \nWords to search for within this puzzle");
            wordString = Console.ReadLine();
            wordArray = wordString.Split(seperators, StringSplitOptions.None);
            foreach (string str in wordArray)
            {
                wordList.Add(str);
            }
            //I am realizing after the fact that most of the above could be simplified down into a function. hmmm 


            //ok now we wnt to create some tile objects.
            createTiles();

            //a little printline to comment out later. it tells me if things have been entered properly.
            //changed my mind. i want to keep this just so that the other programmers can see it. Ill just clean it a bit.
            Console.WriteLine("");
            Console.WriteLine("Tileset Information:");
            Console.WriteLine("Letter,column,row,letterMultiplier,tileMultiplier:");
            foreach (ScroggleTile t in allTiles)
            {
                t.printAllValues();
            }

            Console.WriteLine("");
            Console.WriteLine("Press ENTER to solve.");
            Console.Read();
        }

        private void createTiles()
        {
            //ok we have gathered and sorted all of our information into arrays. Now we will sort this information further into each tile.


            int letterInd = 0;
            for (int i = 0; i < boardHeight; i++)
            {
                for (int j = 0; j < boardHeight; j++)
                {
                    //ok we use a double for loop in order to create our 2d array of tiles. (it will exist in 1d but will have 2D coordinates.)
                    //here we set the simple values for a tile.
                    ScroggleTile t = new ScroggleTile();
                    t.SetLetter(lettersInOrderArray[letterInd]);
                    t.SetGridLocationCol(j);
                    t.SetGridLocationRow(i);

                    //now for the more complicated variables to assign.
                    //first tile bonuses.

                    foreach (string str in doubleValCoordArray)
                    {
                        //quickly iterate through the list and if the location coordinate matches this tile change its value.
                        if (str.Equals(j + "." + i))
                        {
                            t.SetTileMultiplier(2);
                        }
                    }
                    //above: 2x multiplier, below: 3x multiplier.
                    foreach (string str in tripleValCoordArray)
                    {
                        if (str.Equals(j + "." + i))
                        {
                            t.SetTileMultiplier(3);
                        }
                    }

                    //now to set appropreate letter bonuses where needed
                    foreach (string str in doubleValLetArray)
                    {
                        //iterate through array. if the letter assigned to T matches a letter that gets a bonus then set the bonus in the tile.
                        if (str.Equals(lettersInOrderArray[letterInd]))
                        {
                            t.SetLetterMultiplier(2);
                        }
                    }
                    //same as above except for 3x multipliers.
                    foreach (string str in tripleValLetArray)
                    {
                        if (str.Equals(lettersInOrderArray[letterInd]))
                        {
                            t.SetLetterMultiplier(3);
                        }
                    }

                    allTiles.Add(t);
                    letterInd++;
                }
            }
        }

        /// <summary>
        /// Iterates through array of tiles and begins the solving proccess.
        /// </summary>
        /// <param name="ss"></param>
        private void SolveScroggle(ScroggleSolver ss)
        {
            foreach (ScroggleTile st in allTiles)
            {
                st.RSolve(ss,wordList,allTiles,blackList,1,"");
            }
        }

        /// <summary>
        /// Prints all final values after solving the puzzle to the screen.
        /// </summary>
        private void PrintFinalVals()
        {
            //print all of the information gathered onto screen.
            Console.WriteLine("");
            foreach (string str in foundWords)
            {
                Console.WriteLine(str);
            }
            Console.WriteLine("Final Score:" + score);
            Console.WriteLine("");
        }

        /// <summary>
        /// a method that is called when the tiles find a word in the solution. 
        /// Performs minor calculations to figure out the final score for the word then saves value to appropreate variables and arrays.
        /// </summary>
        /// <param name="newWord"></param>
        /// <param name="mult"></param>
        public void ReceiveWordAndScore(string newWord, int mult)
        {
            //we have been given a word and multiplier. we can use that to calculate a proper score.
            int i = newWord.Length;
            int singleWordScore = 0;
            //to get the words score we quickly check the words length and use the given values.
            switch (i)
            {
                case 1:
                    //in case somone wants to make 3 or less letter words scred they can with this value. just change at the top.
                    singleWordScore = oneToThreeLetterBaseScore;
                    break;
                case 2:
                    singleWordScore = oneToThreeLetterBaseScore;
                    break;
                case 3:
                    singleWordScore = oneToThreeLetterBaseScore;
                    break;
                case 4:
                    singleWordScore = fourLetterWordBaseScore * mult;
                    break;

                case 5:
                    singleWordScore = fiveLetterWordBaseScore * mult;
                    break;

                case 6:
                    singleWordScore = sixLetterWordBaseScore * mult;
                    break;

                case 7:
                    singleWordScore = sevenLetterWordBaseScore * mult;
                    break;

                default:
                    singleWordScore = eightLetterWordBaseScore * mult;
                    break;
            }

            //lastly add the score to the total and add the word to the list of found words.
            score += singleWordScore;
            wordScore.Add(singleWordScore);
            foundWords.Add(newWord);

        }
    }
}
