﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Scroggle
{
    /// <summary>
    /// Class that models the behavior of an individual tile. 
    /// Also contains the method needed to solve the puzzle.
    /// </summary>
    public class ScroggleTile
    {
        private string letter;
        private int gridLocationCol;
        private int gridLocationRow;
        private int letterMultiplier = 1;
        private int tileMultiplier = 1;

        //--------------------------- Getters & setters ----------------------------- 

        /// <summary>
        /// Sets the column location of this tile
        /// </summary>
        /// <param name="i">The index.</param>
        public void SetGridLocationCol(int i)
        {
            gridLocationCol = i;
        }

        /// <summary>
        /// Sets the grid location row.
        /// </summary>
        /// <param name="i">The index.</param>
        public void SetGridLocationRow(int i)
        {
            gridLocationRow = i;
        }

        /// <summary>
        /// Sets the tile multiplier.
        /// </summary>
        /// <param name="i">The index.</param>
        public void SetTileMultiplier(int i)
        {
            tileMultiplier = i;
        }

        /// <summary>
        /// sets the tiles letter.
        /// </summary>
        /// <param name="l"></param>
        public void SetLetter(string l)
        {
            letter = l;
        }

        /// <summary>
        /// tells the tile to hold a multiplier value correspondant to a specific letter.
        /// </summary>
        /// <param name="i"></param>
        public void SetLetterMultiplier(int i)
        {
            letterMultiplier = i;
        }

        /// <summary>
        /// returns the column of this tile 
        /// </summary>
        /// <returns></returns>
        public int GetGridLocationCol()
        {
            return gridLocationCol;
        }

        /// <summary>
        /// returns the row of this tile.
        /// </summary>
        /// <returns></returns>
        public int GetGridLocationRow()
        {
            return gridLocationRow;
        }

        //------------------------ Functions ---------------------------

        /// <summary>
        /// prints all values to console for evaluation purposes.
        /// </summary>
        public void printAllValues()
        {
            string s = (letter + ", " + gridLocationCol + ", " + gridLocationRow + ", " + letterMultiplier + ", " + tileMultiplier);
            Console.WriteLine(s);
        }

        /// <summary>
        /// A recursive method that calls tiles to solve the puzzle.
        /// </summary>
        /// <param name="sol">Sol.</param>
        /// <param name="wordList">Word list.</param>
        /// <param name="boardList">Board list.</param>
        /// <param name="blackList">Black list.</param>
        /// <param name="currentWordMultiplier">Current word multiplier.</param>
        /// <param name="currentWord">Current word.</param>
        public void RSolve(ScroggleSolver sol, List<string> wordList, List<ScroggleTile> boardList, List<ScroggleTile> blackList, int currentWordMultiplier, string currentWord)
        {
            //im sure unit testing would come VERY in handy for this method! >.<

            //create some temporary variables. these will be passed to the next level of recursion or dropped entirely.
            string newWord = currentWord + letter;
            string ts; //temporary string.
            int mult = currentWordMultiplier * letterMultiplier * tileMultiplier;
            List<string> newWordList = new List<string>();
            List<ScroggleTile> tempNeibours = new List<ScroggleTile>();
            List<ScroggleTile> alertList = new List<ScroggleTile>();//list of tiles to alert or query.

            //an odd issue with pass by reference Vs. pass by copy has occured. the folling is my way around that.
            List<ScroggleTile> newBlackList = new List<ScroggleTile>();
            List<string> wordsToRemove = new List<string>();

            //basically we have to create new list instances and pass those to the children.
            foreach (string str in wordList)
            {
                newWordList.Add(str);
            }
            foreach (ScroggleTile st in blackList)
            {
                newBlackList.Add(st);
            }



            //first check for any perfect matches. these will get reported to the solver.
            if (newWordList.Contains(newWord))
            {
                //report the word to the solver.
                sol.ReceiveWordAndScore(newWord, mult);
                //remove this word fromm the list so it cant be counted more than once.
                newWordList.Remove(newWord);
            }

            //then any partial matches. so we can pass these values to the next round.
            foreach (string s in newWordList)
            {
                //break it down into a substring the same size as the string we need to compare it to.
                ts = s.Substring(0, newWord.Length);
                if (!ts.Equals(newWord))
                {
                    //if the word does not match the string we are making then que it to be removed
                    wordsToRemove.Add(s);
                }
            }

            //next we need to remove any words from the wordlist that no longer match up to the word we have.
            foreach (string s in wordsToRemove)
            {
                newWordList.Remove(s);
            }

            //add this tile to the future tile blacklist so it cant get reused.
            newBlackList.Add(this);


            //now if the remaining word list has even a single value in it we need to check out neibours
            if (newWordList.Count > 0)
            {
                //populate the temporary list as we do not want to edit the original list.
                foreach (ScroggleTile st in boardList)
                {
                    tempNeibours.Add(st);
                }
                //check the list of neibours for blacklisted enteries, if so remove them from the list.
                foreach (ScroggleTile st in newBlackList)
                {
                    tempNeibours.Remove(st);
                }

                //so use arithmetic to navigate the graph and grab a list of all applicable neibours.

                foreach (ScroggleTile st in tempNeibours)
                {
                    //this may be a tough one here.
                    //iterate through all of the neibours that arnt blacklisted. 
                    //compare their location (colums and rows)to yours. if they are within one unit (+1/-1) then place them in the neibours list. 
                    int col = st.GetGridLocationCol();
                    int row = st.GetGridLocationRow();
                    //number >= availableRangeBegin && number <= availableRangeEnd
                    if ((col >= (gridLocationCol-1) && col <= (gridLocationCol+1)) && (row >= (gridLocationRow-1) && row <= (gridLocationRow+1)))
                    {
                        alertList.Add(st);
                    }
                }

                //call this function on every member of the list neibour list.
                foreach (ScroggleTile st in alertList)
                {
                    st.RSolve(sol, newWordList, boardList, newBlackList, mult, newWord);
                }
            }


            //if our word list has nothing in it then we have tried every possible answer. return to sender!
            return;



        }



    }
}
