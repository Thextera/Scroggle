This is the quick guide for the ScroggleSolver program!

Click Scroggle.exe which is located under "ScroggleSolver/Scroggle/bin/Debug" to run the program. Follow the on-screen instructions to solve
any Scroggle puzzle imaginable!

Charm_ProgrammingAssignmentNotes Are notes from the programmer on his experience during and after the making of this program.
read and enjoy!

Lastly to veiw the programming itself either access the Scroggle.sln file with Microsoft's Visual Studio to see the project
OR veiw ScroggleSolver.cs and Tile.cs under the "ScroggleSolver/Scroggle" Directory with any program that understands .cs files.

Enjoy!